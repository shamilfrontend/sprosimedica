1. copy to this directory "ckeditor" directory with CKEditor
2. copy this plugin to ckeditor/plugins