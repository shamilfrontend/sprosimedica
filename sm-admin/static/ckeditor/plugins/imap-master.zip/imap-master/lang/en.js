CKEDITOR.plugins.setLang( 'imap', 'en',
{
	fake_object_label: 'Map',
	title: 'Map',
	f_name: 'Name',
	f_label: 'Label',
	f_width: 'Width',
	f_height: 'height',
	f_lon: 'Longitude',
	f_lat: 'Latitude',
	f_zoom: 'Zoom',
	inc_coord: 'Incorrect coordinate',
	inc_zoom: 'Incorrect zoom (1-17)',
	button_label: 'Insert a map'
} );