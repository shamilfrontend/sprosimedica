﻿CKEDITOR.plugins.setLang( 'imap', 'ru',
{
	fake_object_label: 'Карта',
	title: 'Карта',
	f_name: 'Наименование',
	f_label: 'Метка',
	f_width: 'Ширина',
	f_height: 'Высота',
	f_lon: 'Долгота',
	f_lat: 'Широта',
	f_zoom: 'Масштаб',
	button_label: 'Разместить карту',
	inc_coord: 'Указана некорректная координата',
	inc_zoom: 'Некорректный масштаб'
} );